namespace ENiagara_UnsetDirectSet {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagara_MAX = 2,
    };
}

