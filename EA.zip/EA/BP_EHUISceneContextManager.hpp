#ifndef UE4SS_SDK_BP_EHUISceneContextManager_HPP
#define UE4SS_SDK_BP_EHUISceneContextManager_HPP

class UBP_EHUISceneContextManager_C : public UTGUISceneContextManager
{
};

#endif
