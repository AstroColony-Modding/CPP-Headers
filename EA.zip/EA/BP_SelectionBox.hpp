#ifndef UE4SS_SDK_BP_SelectionBox_HPP
#define UE4SS_SDK_BP_SelectionBox_HPP

class UBP_SelectionBox_C : public UEHBoxComponent
{
};

#endif
