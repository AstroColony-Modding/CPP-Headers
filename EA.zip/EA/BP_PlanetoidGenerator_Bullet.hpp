#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Bullet_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Bullet_HPP

class UBP_PlanetoidGenerator_Bullet_C : public UPlanetoidGenerator
{
};

#endif
