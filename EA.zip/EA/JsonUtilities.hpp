#ifndef UE4SS_SDK_JsonUtilities_HPP
#define UE4SS_SDK_JsonUtilities_HPP

struct FJsonObjectWrapper
{
    FString JsonString;

};

class UJsonUtilitiesDummyObject : public UObject
{
};

#endif
