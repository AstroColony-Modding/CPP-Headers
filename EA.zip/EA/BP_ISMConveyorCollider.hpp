#ifndef UE4SS_SDK_BP_ISMConveyorCollider_HPP
#define UE4SS_SDK_BP_ISMConveyorCollider_HPP

class UBP_ISMConveyorCollider_C : public UBP_ISMBaseCollider_C
{
};

#endif
