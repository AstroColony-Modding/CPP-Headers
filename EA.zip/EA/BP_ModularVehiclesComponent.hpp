#ifndef UE4SS_SDK_BP_ModularVehiclesComponent_HPP
#define UE4SS_SDK_BP_ModularVehiclesComponent_HPP

class UBP_ModularVehiclesComponent_C : public UEHModularVehicles
{
};

#endif
