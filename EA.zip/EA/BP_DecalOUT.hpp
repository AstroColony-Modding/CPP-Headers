#ifndef UE4SS_SDK_BP_DecalOUT_HPP
#define UE4SS_SDK_BP_DecalOUT_HPP

class UBP_DecalOUT_C : public UEHDecalComponent
{
};

#endif
