#ifndef UE4SS_SDK_BP_ThrusterComponent_HPP
#define UE4SS_SDK_BP_ThrusterComponent_HPP

class UBP_ThrusterComponent_C : public UBP_ModularChildActorComponent_C
{
};

#endif
