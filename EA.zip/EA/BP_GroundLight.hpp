#ifndef UE4SS_SDK_BP_GroundLight_HPP
#define UE4SS_SDK_BP_GroundLight_HPP

class UBP_GroundLight_C : public UPointLightComponent
{
};

#endif
