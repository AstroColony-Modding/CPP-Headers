#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Crater_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Crater_HPP

class UBP_PlanetoidGenerator_Crater_C : public UPlanetoidGenerator_Crater
{
};

#endif
