enum class EMovementReplicationMethod {
    ClientSidePredictionAntiCheat = 0,
    ServerSideReplication = 1,
    EMovementReplicationMethod_MAX = 2,
};

