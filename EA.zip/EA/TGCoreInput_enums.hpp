enum class ETGInputEvent {
    Press = 0,
    Release = 1,
    Repeat = 2,
    Hold = 3,
    ETGInputEvent_MAX = 4,
};

