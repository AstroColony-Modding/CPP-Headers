#ifndef UE4SS_SDK_BP_ReactiveFarmGateBlue_HPP
#define UE4SS_SDK_BP_ReactiveFarmGateBlue_HPP

class UBP_ReactiveFarmGateBlue_C : public UEHReactiveHISMComponent
{
};

#endif
