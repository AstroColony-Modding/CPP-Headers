#ifndef UE4SS_SDK_BP_Scenario1_CraftingConstruction_HPP
#define UE4SS_SDK_BP_Scenario1_CraftingConstruction_HPP

class UBP_Scenario1_CraftingConstruction_C : public UEHScenarioComponent
{
};

#endif
