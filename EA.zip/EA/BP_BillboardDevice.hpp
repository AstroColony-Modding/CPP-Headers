#ifndef UE4SS_SDK_BP_BillboardDevice_HPP
#define UE4SS_SDK_BP_BillboardDevice_HPP

class UBP_BillboardDevice_C : public UEHBillboardsLineComponent
{
};

#endif
