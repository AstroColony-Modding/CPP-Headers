#ifndef UE4SS_SDK_BP_ReactiveDisk_HPP
#define UE4SS_SDK_BP_ReactiveDisk_HPP

class UBP_ReactiveDisk_C : public UEHReactiveHISMComponent
{
};

#endif
