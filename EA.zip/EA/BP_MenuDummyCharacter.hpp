#ifndef UE4SS_SDK_BP_MenuDummyCharacter_HPP
#define UE4SS_SDK_BP_MenuDummyCharacter_HPP

class ABP_MenuDummyCharacter_C : public AEHCharacter
{
    class UBP_InventoryComponent_C* BP_InventoryComponent;

};

#endif
