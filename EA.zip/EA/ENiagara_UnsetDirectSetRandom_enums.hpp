namespace ENiagara_UnsetDirectSetRandom {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator3 = 2,
        ENiagara_MAX = 3,
    };
}

