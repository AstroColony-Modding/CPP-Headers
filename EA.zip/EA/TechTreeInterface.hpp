#ifndef UE4SS_SDK_TechTreeInterface_HPP
#define UE4SS_SDK_TechTreeInterface_HPP

class ITechTreeInterface_C : public IInterface
{

    void JumpToTechnology(class UTechnologyAsset* TechnologyAsset);
};

#endif
