enum class EDesiredImageFormat {
    PNG = 0,
    JPG = 1,
    BMP = 2,
    EXR = 3,
    EDesiredImageFormat_MAX = 4,
};

