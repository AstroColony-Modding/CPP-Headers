enum class ETechTreeOrientation {
    Vertical = 0,
    Horizontal = 1,
    Custom = 2,
    ETechTreeOrientation_MAX = 3,
};

enum class ETechNodePinType {
    Input = 0,
    Output = 1,
    ETechNodePinType_MAX = 2,
};

