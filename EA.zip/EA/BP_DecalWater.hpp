#ifndef UE4SS_SDK_BP_DecalWater_HPP
#define UE4SS_SDK_BP_DecalWater_HPP

class UBP_DecalWater_C : public UEHDecalComponent
{
};

#endif
