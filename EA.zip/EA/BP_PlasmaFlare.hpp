#ifndef UE4SS_SDK_BP_PlasmaFlare_HPP
#define UE4SS_SDK_BP_PlasmaFlare_HPP

class UBP_PlasmaFlare_C : public UEHFlareComponent
{
};

#endif
