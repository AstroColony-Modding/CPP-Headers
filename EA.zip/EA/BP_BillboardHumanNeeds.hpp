#ifndef UE4SS_SDK_BP_BillboardHumanNeeds_HPP
#define UE4SS_SDK_BP_BillboardHumanNeeds_HPP

class UBP_BillboardHumanNeeds_C : public UEHBillboardsLineComponent
{
};

#endif
