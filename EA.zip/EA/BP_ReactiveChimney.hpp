#ifndef UE4SS_SDK_BP_ReactiveChimney_HPP
#define UE4SS_SDK_BP_ReactiveChimney_HPP

class UBP_ReactiveChimney_C : public UEHReactiveHISMComponent
{
};

#endif
