namespace ENiagara_SpriteRotationMode {
    enum Type {
        NewEnumerator3 = 0,
        NewEnumerator2 = 1,
        NewEnumerator0 = 2,
        NewEnumerator1 = 3,
        ENiagara_MAX = 4,
    };
}

