#ifndef UE4SS_SDK_MPScenarioParamsOld_HPP
#define UE4SS_SDK_MPScenarioParamsOld_HPP

struct FMPScenarioParamsOld
{
    int32 SeedNumber_2_1CA7ADB14CD815F337DA6FBEEE1077C4;
    bool PlayerConsumesOxygen_5_6422FD374D14EC14E2C5A4994D017A69;
    bool StartCampaign_7_742CF1A64728D9DC22913D981B53260A;
    bool ShaderTechnologyPoints_10_1DA3826E4B89D69722DF2886BC6D496A;
    bool SharedTechnologies_11_9F0D0F024E3A6560126CD781FE067CEC;

};

#endif
