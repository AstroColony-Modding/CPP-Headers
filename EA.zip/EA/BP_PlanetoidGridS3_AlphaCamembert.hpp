#ifndef UE4SS_SDK_BP_PlanetoidGridS3_AlphaCamembert_HPP
#define UE4SS_SDK_BP_PlanetoidGridS3_AlphaCamembert_HPP

class ABP_PlanetoidGridS3_AlphaCamembert_C : public ABP_PlanetoidGrid_C
{
};

#endif
