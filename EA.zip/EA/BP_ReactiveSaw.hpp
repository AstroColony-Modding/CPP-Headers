#ifndef UE4SS_SDK_BP_ReactiveSaw_HPP
#define UE4SS_SDK_BP_ReactiveSaw_HPP

class UBP_ReactiveSaw_C : public UEHReactiveHISMComponent
{
};

#endif
