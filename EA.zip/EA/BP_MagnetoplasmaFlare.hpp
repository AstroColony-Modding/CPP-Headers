#ifndef UE4SS_SDK_BP_MagnetoplasmaFlare_HPP
#define UE4SS_SDK_BP_MagnetoplasmaFlare_HPP

class UBP_MagnetoplasmaFlare_C : public UEHFlareComponent
{
    FLinearColor Color;

};

#endif
