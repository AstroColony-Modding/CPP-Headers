#ifndef UE4SS_SDK_BP_CollectiveColliderFloor_HPP
#define UE4SS_SDK_BP_CollectiveColliderFloor_HPP

class UBP_CollectiveColliderFloor_C : public UEHBoxComponent
{
};

#endif
