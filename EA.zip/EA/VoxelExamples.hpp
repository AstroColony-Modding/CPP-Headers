#ifndef UE4SS_SDK_VoxelExamples_HPP
#define UE4SS_SDK_VoxelExamples_HPP

class UVoxelExamplesModuleDummy : public UObject
{
};

#endif
