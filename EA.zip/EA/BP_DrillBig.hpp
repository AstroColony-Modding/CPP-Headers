#ifndef UE4SS_SDK_BP_DrillBig_HPP
#define UE4SS_SDK_BP_DrillBig_HPP

class ABP_DrillBig_C : public ABP_Drill_C
{
};

#endif
