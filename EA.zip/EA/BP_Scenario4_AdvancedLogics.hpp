#ifndef UE4SS_SDK_BP_Scenario4_AdvancedLogics_HPP
#define UE4SS_SDK_BP_Scenario4_AdvancedLogics_HPP

class UBP_Scenario4_AdvancedLogics_C : public UEHScenarioComponent
{
};

#endif
