#ifndef UE4SS_SDK_LS_RacingStation_HPP
#define UE4SS_SDK_LS_RacingStation_HPP

class ALS_RacingStation_C : public ALevelScriptActor
{
};

#endif
