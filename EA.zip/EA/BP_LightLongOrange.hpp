#ifndef UE4SS_SDK_BP_LightLongOrange_HPP
#define UE4SS_SDK_BP_LightLongOrange_HPP

class UBP_LightLongOrange_C : public UPointLightComponent
{
};

#endif
