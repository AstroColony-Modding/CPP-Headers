#ifndef UE4SS_SDK_BP_LightPoleRound_HPP
#define UE4SS_SDK_BP_LightPoleRound_HPP

class UBP_LightPoleRound_C : public UPointLightComponent
{
};

#endif
