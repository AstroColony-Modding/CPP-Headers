#ifndef UE4SS_SDK_BP_LightPoleOval_HPP
#define UE4SS_SDK_BP_LightPoleOval_HPP

class UBP_LightPoleOval_C : public UPointLightComponent
{
};

#endif
