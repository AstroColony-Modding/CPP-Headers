#ifndef UE4SS_SDK_BP_ActorMacros_HPP
#define UE4SS_SDK_BP_ActorMacros_HPP

class ABP_ActorMacros_C : public AActor
{
};

#endif
