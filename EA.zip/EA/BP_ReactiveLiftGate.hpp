#ifndef UE4SS_SDK_BP_ReactiveLiftGate_HPP
#define UE4SS_SDK_BP_ReactiveLiftGate_HPP

class UBP_ReactiveLiftGate_C : public UEHReactiveHISMComponent
{
};

#endif
