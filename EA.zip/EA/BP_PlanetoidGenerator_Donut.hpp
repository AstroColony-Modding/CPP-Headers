#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Donut_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Donut_HPP

class UBP_PlanetoidGenerator_Donut_C : public UPlanetoidGenerator_Donut
{
};

#endif
