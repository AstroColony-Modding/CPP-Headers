#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Fang_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Fang_HPP

class UBP_PlanetoidGenerator_Fang_C : public UPlanetoidGenerator_Fang
{
};

#endif
