#ifndef UE4SS_SDK_BP_ReactiveShaderGateRound_HPP
#define UE4SS_SDK_BP_ReactiveShaderGateRound_HPP

class UBP_ReactiveShaderGateRound_C : public UEHReactiveHISMComponent
{
};

#endif
