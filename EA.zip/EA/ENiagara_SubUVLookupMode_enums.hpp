namespace ENiagara_SubUVLookupMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator3 = 3,
        ENiagara_MAX = 4,
    };
}

