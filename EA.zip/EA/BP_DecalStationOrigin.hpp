#ifndef UE4SS_SDK_BP_DecalStationOrigin_HPP
#define UE4SS_SDK_BP_DecalStationOrigin_HPP

class UBP_DecalStationOrigin_C : public UEHDecalComponent
{
};

#endif
