#ifndef UE4SS_SDK_BP_EHUILoadingScreenManager_HPP
#define UE4SS_SDK_BP_EHUILoadingScreenManager_HPP

class UBP_EHUILoadingScreenManager_C : public UTGUILoadingScreenManager
{
};

#endif
