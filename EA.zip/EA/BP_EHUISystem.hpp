#ifndef UE4SS_SDK_BP_EHUISystem_HPP
#define UE4SS_SDK_BP_EHUISystem_HPP

class UBP_EHUISystem_C : public UEHUISystem
{
};

#endif
