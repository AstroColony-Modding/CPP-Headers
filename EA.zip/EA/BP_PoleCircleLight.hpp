#ifndef UE4SS_SDK_BP_PoleCircleLight_HPP
#define UE4SS_SDK_BP_PoleCircleLight_HPP

class UBP_PoleCircleLight_C : public UPointLightComponent
{
};

#endif
