#ifndef UE4SS_SDK_BP_SpaceCarryComponent_HPP
#define UE4SS_SDK_BP_SpaceCarryComponent_HPP

class UBP_SpaceCarryComponent_C : public UEHSpaceCarryComponent
{
};

#endif
