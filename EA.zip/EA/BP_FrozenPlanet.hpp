#ifndef UE4SS_SDK_BP_FrozenPlanet_HPP
#define UE4SS_SDK_BP_FrozenPlanet_HPP

class ABP_FrozenPlanet_C : public ABP_PlanetoidGrid_C
{
};

#endif
