#ifndef UE4SS_SDK_BP_LandingLegsComponent_HPP
#define UE4SS_SDK_BP_LandingLegsComponent_HPP

class UBP_LandingLegsComponent_C : public UBP_ModularChildActorComponent_C
{
};

#endif
