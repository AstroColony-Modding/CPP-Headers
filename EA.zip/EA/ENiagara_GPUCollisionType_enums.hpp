namespace ENiagara_GPUCollisionType {
    enum Type {
        NewEnumerator1 = 0,
        NewEnumerator2 = 1,
        NewEnumerator3 = 2,
        ENiagara_MAX = 3,
    };
}

