#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Boomerang_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Boomerang_HPP

class UBP_PlanetoidGenerator_Boomerang_C : public UPlanetoidGenerator_Donut
{
};

#endif
