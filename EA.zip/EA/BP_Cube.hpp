#ifndef UE4SS_SDK_BP_Cube_HPP
#define UE4SS_SDK_BP_Cube_HPP

class ABP_Cube_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
