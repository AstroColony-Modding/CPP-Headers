namespace ENiagaraExpansionMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ENiagaraExpansionMode_MAX = 3,
    };
}

