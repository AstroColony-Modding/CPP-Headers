#ifndef UE4SS_SDK_BP_ReactiveShaderGatePlanksRed_HPP
#define UE4SS_SDK_BP_ReactiveShaderGatePlanksRed_HPP

class UBP_ReactiveShaderGatePlanksRed_C : public UEHReactiveHISMComponent
{
};

#endif
