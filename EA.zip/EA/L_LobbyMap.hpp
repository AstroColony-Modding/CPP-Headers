#ifndef UE4SS_SDK_L_LobbyMap_HPP
#define UE4SS_SDK_L_LobbyMap_HPP

class AL_LobbyMap_C : public ALevelScriptActor
{
};

#endif
