#ifndef UE4SS_SDK_BP_CollectiveColliderWall_HPP
#define UE4SS_SDK_BP_CollectiveColliderWall_HPP

class UBP_CollectiveColliderWall_C : public UEHBoxComponent
{
};

#endif
