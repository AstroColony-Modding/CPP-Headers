#ifndef UE4SS_SDK_BP_RacingRover_HPP
#define UE4SS_SDK_BP_RacingRover_HPP

class ABP_RacingRover_C : public ABP_RoverPawn_C
{

    void PossesReact(bool IsPossessed);
};

#endif
