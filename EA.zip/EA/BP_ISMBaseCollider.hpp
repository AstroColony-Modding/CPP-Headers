#ifndef UE4SS_SDK_BP_ISMBaseCollider_HPP
#define UE4SS_SDK_BP_ISMBaseCollider_HPP

class UBP_ISMBaseCollider_C : public UEHInstancedStaticMeshComponent
{
};

#endif
