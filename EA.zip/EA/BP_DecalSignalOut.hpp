#ifndef UE4SS_SDK_BP_DecalSignalOut_HPP
#define UE4SS_SDK_BP_DecalSignalOut_HPP

class UBP_DecalSignalOut_C : public UEHDecalComponent
{
};

#endif
