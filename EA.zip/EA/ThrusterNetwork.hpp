#ifndef UE4SS_SDK_ThrusterNetwork_HPP
#define UE4SS_SDK_ThrusterNetwork_HPP

class UThrusterNetwork_C : public UEHThrusterNetwork
{
};

#endif
