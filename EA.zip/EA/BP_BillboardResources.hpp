#ifndef UE4SS_SDK_BP_BillboardResources_HPP
#define UE4SS_SDK_BP_BillboardResources_HPP

class UBP_BillboardResources_C : public UEHBillboardsLineComponent
{
};

#endif
