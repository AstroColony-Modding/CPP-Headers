#ifndef UE4SS_SDK_BP_UIPopupFactory_HPP
#define UE4SS_SDK_BP_UIPopupFactory_HPP

class UBP_UIPopupFactory_C : public UEHUIPopupManager
{
};

#endif
