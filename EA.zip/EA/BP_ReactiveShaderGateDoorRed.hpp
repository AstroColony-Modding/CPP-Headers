#ifndef UE4SS_SDK_BP_ReactiveShaderGateDoorRed_HPP
#define UE4SS_SDK_BP_ReactiveShaderGateDoorRed_HPP

class UBP_ReactiveShaderGateDoorRed_C : public UEHReactiveHISMComponent
{
};

#endif
