#ifndef UE4SS_SDK_BP_ReactiveShaderGateLaser_HPP
#define UE4SS_SDK_BP_ReactiveShaderGateLaser_HPP

class UBP_ReactiveShaderGateLaser_C : public UEHReactiveHISMComponent
{
};

#endif
