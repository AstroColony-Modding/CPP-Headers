#ifndef UE4SS_SDK_L_StationS_Basic_HPP
#define UE4SS_SDK_L_StationS_Basic_HPP

class AL_StationS_Basic_C : public ALevelScriptActor
{
};

#endif
