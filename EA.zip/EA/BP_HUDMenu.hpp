#ifndef UE4SS_SDK_BP_HUDMenu_HPP
#define UE4SS_SDK_BP_HUDMenu_HPP

class ABP_HUDMenu_C : public AEHHUDMenu
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
