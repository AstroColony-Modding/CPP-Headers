#ifndef UE4SS_SDK_BP_ISMBlockCollider_HPP
#define UE4SS_SDK_BP_ISMBlockCollider_HPP

class UBP_ISMBlockCollider_C : public UBP_ISMBaseCollider_C
{
};

#endif
