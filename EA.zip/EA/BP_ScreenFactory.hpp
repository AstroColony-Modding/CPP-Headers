#ifndef UE4SS_SDK_BP_ScreenFactory_HPP
#define UE4SS_SDK_BP_ScreenFactory_HPP

class UBP_ScreenFactory_C : public UEHScreenManager
{
};

#endif
