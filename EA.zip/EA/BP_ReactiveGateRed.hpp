#ifndef UE4SS_SDK_BP_ReactiveGateRed_HPP
#define UE4SS_SDK_BP_ReactiveGateRed_HPP

class UBP_ReactiveGateRed_C : public UEHReactiveHISMComponent
{
};

#endif
