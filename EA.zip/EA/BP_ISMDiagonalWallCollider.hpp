#ifndef UE4SS_SDK_BP_ISMDiagonalWallCollider_HPP
#define UE4SS_SDK_BP_ISMDiagonalWallCollider_HPP

class UBP_ISMDiagonalWallCollider_C : public UBP_ISMBaseCollider_C
{
};

#endif
