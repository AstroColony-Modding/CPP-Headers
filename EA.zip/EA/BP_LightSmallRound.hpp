#ifndef UE4SS_SDK_BP_LightSmallRound_HPP
#define UE4SS_SDK_BP_LightSmallRound_HPP

class UBP_LightSmallRound_C : public UPointLightComponent
{
};

#endif
