enum class EClothingWindMethodNv {
    Legacy = 0,
    Accurate = 1,
    EClothingWindMethodNv_MAX = 2,
};

