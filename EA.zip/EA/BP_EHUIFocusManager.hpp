#ifndef UE4SS_SDK_BP_EHUIFocusManager_HPP
#define UE4SS_SDK_BP_EHUIFocusManager_HPP

class UBP_EHUIFocusManager_C : public UTGUIFocusManager
{
};

#endif
