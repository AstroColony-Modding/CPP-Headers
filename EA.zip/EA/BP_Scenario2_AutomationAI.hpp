#ifndef UE4SS_SDK_BP_Scenario2_AutomationAI_HPP
#define UE4SS_SDK_BP_Scenario2_AutomationAI_HPP

class UBP_Scenario2_AutomationAI_C : public UEHScenarioComponent
{
};

#endif
