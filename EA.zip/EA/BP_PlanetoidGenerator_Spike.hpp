#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Spike_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Spike_HPP

class UBP_PlanetoidGenerator_Spike_C : public UPlanetoidGenerator_Spike
{
};

#endif
