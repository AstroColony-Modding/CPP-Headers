#ifndef UE4SS_SDK_BP_SaveGame_HPP
#define UE4SS_SDK_BP_SaveGame_HPP

class UBP_SaveGame_C : public UEHSaveGame
{
    bool JetpackOn_0;
    EHJobModeType JobMode;

};

#endif
