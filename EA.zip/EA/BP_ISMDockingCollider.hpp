#ifndef UE4SS_SDK_BP_ISMDockingCollider_HPP
#define UE4SS_SDK_BP_ISMDockingCollider_HPP

class UBP_ISMDockingCollider_C : public UBP_ISMBaseCollider_C
{
};

#endif
