#ifndef UE4SS_SDK_VoxelS3_FlyingFrozen_HPP
#define UE4SS_SDK_VoxelS3_FlyingFrozen_HPP

class AVoxelS3_FlyingFrozen_C : public ABP_VoxelWorld_C
{
};

#endif
