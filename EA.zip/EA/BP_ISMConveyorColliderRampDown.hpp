#ifndef UE4SS_SDK_BP_ISMConveyorColliderRampDown_HPP
#define UE4SS_SDK_BP_ISMConveyorColliderRampDown_HPP

class UBP_ISMConveyorColliderRampDown_C : public UBP_ISMBaseCollider_C
{
};

#endif
