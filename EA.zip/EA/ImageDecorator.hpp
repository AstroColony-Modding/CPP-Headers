#ifndef UE4SS_SDK_ImageDecorator_HPP
#define UE4SS_SDK_ImageDecorator_HPP

class UImageDecorator_C : public URichTextBlockImageDecorator
{
};

#endif
