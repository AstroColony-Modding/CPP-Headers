#ifndef UE4SS_SDK_PauseMultiplayerViewModel_HPP
#define UE4SS_SDK_PauseMultiplayerViewModel_HPP

class UPauseMultiplayerViewModel_C : public UEHPauseViewModel
{
};

#endif
