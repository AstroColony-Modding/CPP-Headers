#ifndef UE4SS_SDK_BP_PlanetoidGeneratorS2_HPP
#define UE4SS_SDK_BP_PlanetoidGeneratorS2_HPP

class UBP_PlanetoidGeneratorS2_C : public UPlanetoidGeneratorOld
{
};

#endif
