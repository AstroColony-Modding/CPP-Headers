#ifndef UE4SS_SDK_BP_HUDLobby_HPP
#define UE4SS_SDK_BP_HUDLobby_HPP

class ABP_HUDLobby_C : public AEHHUDMenu
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
