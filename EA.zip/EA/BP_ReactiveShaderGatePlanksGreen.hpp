#ifndef UE4SS_SDK_BP_ReactiveShaderGatePlanksGreen_HPP
#define UE4SS_SDK_BP_ReactiveShaderGatePlanksGreen_HPP

class UBP_ReactiveShaderGatePlanksGreen_C : public UEHReactiveHISMComponent
{
};

#endif
