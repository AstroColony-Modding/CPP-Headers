#ifndef UE4SS_SDK_BP_ReactiveGateBlue_HPP
#define UE4SS_SDK_BP_ReactiveGateBlue_HPP

class UBP_ReactiveGateBlue_C : public UEHReactiveHISMComponent
{
};

#endif
