#ifndef UE4SS_SDK_BP_MissionsComponent_HPP
#define UE4SS_SDK_BP_MissionsComponent_HPP

class UBP_MissionsComponent_C : public UEHMissionsComponent
{
};

#endif
