#ifndef UE4SS_SDK_BP_ReactiveGate_HPP
#define UE4SS_SDK_BP_ReactiveGate_HPP

class UBP_ReactiveGate_C : public UEHReactiveHISMComponent
{
};

#endif
