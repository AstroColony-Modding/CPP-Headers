#ifndef UE4SS_SDK_PauseMinimalViewModel_HPP
#define UE4SS_SDK_PauseMinimalViewModel_HPP

class UPauseMinimalViewModel_C : public UEHPauseViewModel
{
};

#endif
