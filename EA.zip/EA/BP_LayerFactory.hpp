#ifndef UE4SS_SDK_BP_LayerFactory_HPP
#define UE4SS_SDK_BP_LayerFactory_HPP

class UBP_LayerFactory_C : public UEHLayerManager
{
};

#endif
