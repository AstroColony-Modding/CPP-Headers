#ifndef UE4SS_SDK_BP_DecalElectricity_HPP
#define UE4SS_SDK_BP_DecalElectricity_HPP

class UBP_DecalElectricity_C : public UEHDecalComponent
{
};

#endif
