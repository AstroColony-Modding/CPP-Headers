#ifndef UE4SS_SDK_BP_ReactiveShaderGatePlanksBlue_HPP
#define UE4SS_SDK_BP_ReactiveShaderGatePlanksBlue_HPP

class UBP_ReactiveShaderGatePlanksBlue_C : public UEHReactiveHISMComponent
{
};

#endif
