#ifndef UE4SS_SDK_BP_BetaScenario_HPP
#define UE4SS_SDK_BP_BetaScenario_HPP

class UBP_BetaScenario_C : public UBP_Scenario_C
{
};

#endif
