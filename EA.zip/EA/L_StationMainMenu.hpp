#ifndef UE4SS_SDK_L_StationMainMenu_HPP
#define UE4SS_SDK_L_StationMainMenu_HPP

class AL_StationMainMenu_C : public ALevelScriptActor
{
};

#endif
