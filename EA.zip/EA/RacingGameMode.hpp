#ifndef UE4SS_SDK_RacingGameMode_HPP
#define UE4SS_SDK_RacingGameMode_HPP

class ARacingGameMode_C : public AGameModeBase
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
