#ifndef UE4SS_SDK_BP_SandPlanet_HPP
#define UE4SS_SDK_BP_SandPlanet_HPP

class ABP_SandPlanet_C : public ABP_PlanetoidGrid_C
{
};

#endif
