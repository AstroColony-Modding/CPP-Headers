#ifndef UE4SS_SDK_BP_PlanetoidGeneratorGame_HPP
#define UE4SS_SDK_BP_PlanetoidGeneratorGame_HPP

class UBP_PlanetoidGeneratorGame_C : public UPlanetoidGenerator
{
};

#endif
