#ifndef UE4SS_SDK_BP_BillboardAINeeds_HPP
#define UE4SS_SDK_BP_BillboardAINeeds_HPP

class UBP_BillboardAINeeds_C : public UEHBillboardsLineComponent
{
};

#endif
