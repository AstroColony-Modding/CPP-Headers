#ifndef UE4SS_SDK_BP_EHGameState_HPP
#define UE4SS_SDK_BP_EHGameState_HPP

class ABP_EHGameState_C : public AEHGameState
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
