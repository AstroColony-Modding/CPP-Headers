#ifndef UE4SS_SDK_InputCore_HPP
#define UE4SS_SDK_InputCore_HPP

#include "InputCore_enums.hpp"

struct FKey
{
    FName KeyName;

};

class UInputCoreTypes : public UObject
{
};

#endif
