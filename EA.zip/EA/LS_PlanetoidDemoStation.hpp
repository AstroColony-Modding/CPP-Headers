#ifndef UE4SS_SDK_LS_PlanetoidDemoStation_HPP
#define UE4SS_SDK_LS_PlanetoidDemoStation_HPP

class ALS_PlanetoidDemoStation_C : public ALevelScriptActor
{
};

#endif
