#ifndef UE4SS_SDK_BP_ISMWallCollider_HPP
#define UE4SS_SDK_BP_ISMWallCollider_HPP

class UBP_ISMWallCollider_C : public UBP_ISMBaseCollider_C
{
};

#endif
