#ifndef UE4SS_SDK_BP_ExcavatorComponent_HPP
#define UE4SS_SDK_BP_ExcavatorComponent_HPP

class UBP_ExcavatorComponent_C : public UBP_ModularChildActorComponent_C
{
};

#endif
