#ifndef UE4SS_SDK_BP_ISMFloorCollider_HPP
#define UE4SS_SDK_BP_ISMFloorCollider_HPP

class UBP_ISMFloorCollider_C : public UBP_ISMBaseCollider_C
{
};

#endif
