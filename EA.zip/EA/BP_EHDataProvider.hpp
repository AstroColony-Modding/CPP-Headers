#ifndef UE4SS_SDK_BP_EHDataProvider_HPP
#define UE4SS_SDK_BP_EHDataProvider_HPP

class UBP_EHDataProvider_C : public UEHDataProvider
{
};

#endif
