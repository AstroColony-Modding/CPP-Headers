#ifndef UE4SS_SDK_GeneratedWorldGenerators_HPP
#define UE4SS_SDK_GeneratedWorldGenerators_HPP

class UElipsoidTest : public UVoxelGraphGeneratorHelper
{
};

class UPlanetoidCalculateWaveNoise : public UVoxelGraphGeneratorHelper
{
};

class UPlanetoidCalculateWaveNoise_Spike : public UVoxelGraphGeneratorHelper
{
};

class UPlanetoidWavenessRange_Spike : public UVoxelGraphGeneratorHelper
{
};

class UWavenessRange : public UVoxelGraphGeneratorHelper
{
};

class UWavenessRange_Crater : public UVoxelGraphGeneratorHelper
{
};

#endif
