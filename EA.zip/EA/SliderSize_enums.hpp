namespace SliderSize {
    enum Type {
        NewEnumerator3 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        SliderSize_MAX = 4,
    };
}

