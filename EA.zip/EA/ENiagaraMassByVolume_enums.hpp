namespace ENiagaraMassByVolume {
    enum Type {
        NewEnumerator1 = 0,
        NewEnumerator0 = 1,
        NewEnumerator5 = 2,
        NewEnumerator3 = 3,
        NewEnumerator4 = 4,
        NewEnumerator2 = 5,
        ENiagaraMassByVolume_MAX = 6,
    };
}

