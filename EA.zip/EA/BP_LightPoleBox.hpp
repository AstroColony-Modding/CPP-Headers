#ifndef UE4SS_SDK_BP_LightPoleBox_HPP
#define UE4SS_SDK_BP_LightPoleBox_HPP

class UBP_LightPoleBox_C : public UPointLightComponent
{
};

#endif
