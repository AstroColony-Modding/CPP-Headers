namespace DockingConveyLineActionType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        DockingConveyLineActionType_MAX = 3,
    };
}

