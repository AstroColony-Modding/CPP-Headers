#ifndef UE4SS_SDK_BP_DecalIN_HPP
#define UE4SS_SDK_BP_DecalIN_HPP

class UBP_DecalIN_C : public UEHDecalComponent
{
};

#endif
