#ifndef UE4SS_SDK_BP_LightPoleSquare_HPP
#define UE4SS_SDK_BP_LightPoleSquare_HPP

class UBP_LightPoleSquare_C : public UPointLightComponent
{
};

#endif
