#ifndef UE4SS_SDK_BP_FlareComponent_HPP
#define UE4SS_SDK_BP_FlareComponent_HPP

class UBP_FlareComponent_C : public UEHFlareComponent
{
};

#endif
