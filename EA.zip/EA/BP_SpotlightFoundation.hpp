#ifndef UE4SS_SDK_BP_SpotlightFoundation_HPP
#define UE4SS_SDK_BP_SpotlightFoundation_HPP

class UBP_SpotlightFoundation_C : public USpotLightComponent
{
};

#endif
