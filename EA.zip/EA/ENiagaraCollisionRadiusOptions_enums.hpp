namespace ENiagaraCollisionRadiusOptions {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator3 = 2,
        ENiagaraCollisionRadiusOptions_MAX = 3,
    };
}

