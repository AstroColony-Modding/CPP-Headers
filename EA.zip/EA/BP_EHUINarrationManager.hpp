#ifndef UE4SS_SDK_BP_EHUINarrationManager_HPP
#define UE4SS_SDK_BP_EHUINarrationManager_HPP

class UBP_EHUINarrationManager_C : public UTGUINarrationManager
{
};

#endif
