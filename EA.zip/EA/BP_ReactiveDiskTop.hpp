#ifndef UE4SS_SDK_BP_ReactiveDiskTop_HPP
#define UE4SS_SDK_BP_ReactiveDiskTop_HPP

class UBP_ReactiveDiskTop_C : public UEHReactiveHISMComponent
{
};

#endif
