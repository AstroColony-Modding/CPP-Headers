#ifndef UE4SS_SDK_BP_EHUIAudioManager_HPP
#define UE4SS_SDK_BP_EHUIAudioManager_HPP

class UBP_EHUIAudioManager_C : public UTGUIAudioManager
{
};

#endif
