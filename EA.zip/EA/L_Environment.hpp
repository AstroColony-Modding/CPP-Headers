#ifndef UE4SS_SDK_L_Environment_HPP
#define UE4SS_SDK_L_Environment_HPP

class AL_Environment_C : public ALevelScriptActor
{
};

#endif
