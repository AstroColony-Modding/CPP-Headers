namespace ENiagaraCalculateRadiusOptions {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ENiagaraCalculateRadiusOptions_MAX = 3,
    };
}

