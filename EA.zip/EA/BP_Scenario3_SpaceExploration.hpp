#ifndef UE4SS_SDK_BP_Scenario3_SpaceExploration_HPP
#define UE4SS_SDK_BP_Scenario3_SpaceExploration_HPP

class UBP_Scenario3_SpaceExploration_C : public UEHScenarioComponent
{
};

#endif
