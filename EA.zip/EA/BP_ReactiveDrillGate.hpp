#ifndef UE4SS_SDK_BP_ReactiveDrillGate_HPP
#define UE4SS_SDK_BP_ReactiveDrillGate_HPP

class UBP_ReactiveDrillGate_C : public UEHReactiveHISMComponent
{
};

#endif
