#ifndef UE4SS_SDK_BP_ISMConveyorColliderRamp_HPP
#define UE4SS_SDK_BP_ISMConveyorColliderRamp_HPP

class UBP_ISMConveyorColliderRamp_C : public UBP_ISMBaseCollider_C
{
};

#endif
