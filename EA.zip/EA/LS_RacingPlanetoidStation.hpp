#ifndef UE4SS_SDK_LS_RacingPlanetoidStation_HPP
#define UE4SS_SDK_LS_RacingPlanetoidStation_HPP

class ALS_RacingPlanetoidStation_C : public ALevelScriptActor
{
};

#endif
