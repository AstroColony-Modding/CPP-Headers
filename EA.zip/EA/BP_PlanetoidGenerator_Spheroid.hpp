#ifndef UE4SS_SDK_BP_PlanetoidGenerator_Spheroid_HPP
#define UE4SS_SDK_BP_PlanetoidGenerator_Spheroid_HPP

class UBP_PlanetoidGenerator_Spheroid_C : public UPlanetoidGenerator_Ellipsoid
{
};

#endif
