#ifndef UE4SS_SDK_BP_RoboGate_HPP
#define UE4SS_SDK_BP_RoboGate_HPP

class UBP_RoboGate_C : public UEHReactiveHISMComponent
{
};

#endif
