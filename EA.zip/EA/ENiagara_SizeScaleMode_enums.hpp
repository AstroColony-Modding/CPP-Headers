namespace ENiagara_SizeScaleMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator3 = 1,
        NewEnumerator1 = 2,
        NewEnumerator4 = 3,
        NewEnumerator2 = 4,
        ENiagara_MAX = 5,
    };
}

