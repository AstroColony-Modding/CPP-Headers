#ifndef UE4SS_SDK_BP_LightPoleRectangle_HPP
#define UE4SS_SDK_BP_LightPoleRectangle_HPP

class UBP_LightPoleRectangle_C : public UPointLightComponent
{
};

#endif
