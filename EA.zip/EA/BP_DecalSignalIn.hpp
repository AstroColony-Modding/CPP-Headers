#ifndef UE4SS_SDK_BP_DecalSignalIn_HPP
#define UE4SS_SDK_BP_DecalSignalIn_HPP

class UBP_DecalSignalIn_C : public UEHDecalComponent
{
};

#endif
