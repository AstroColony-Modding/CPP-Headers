namespace ENiagaraEmitterScalabilityMode_Limited {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraEmitterScalabilityMode_MAX = 2,
    };
}

