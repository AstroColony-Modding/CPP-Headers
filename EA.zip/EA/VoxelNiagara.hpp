#ifndef UE4SS_SDK_VoxelNiagara_HPP
#define UE4SS_SDK_VoxelNiagara_HPP

class UNiagaraDataInterfaceVoxelDataAsset : public UNiagaraDataInterface
{
    class UVoxelDataAsset* Asset;

};

#endif
